﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP314.Helpers
{
    public class IdentityErrorDescriptionAz:IdentityErrorDescriber
    {
        public override IdentityError DuplicateEmail(string email)
        {
            return new IdentityError
            {
                Code=nameof(DuplicateEmail),
                Description=$"{email} - artiq movcuddur,zehmet olmasa bashqa email istifade edin!"
            };
        }

        public override IdentityError DuplicateUserName(string userName)
        {
            return new IdentityError
            {
                Code = nameof(DuplicateUserName),
                Description = $"{userName} - artiq movcuddur,zehmet olmasa bashqa user adi sechin!"
            };
        }
    }
}
