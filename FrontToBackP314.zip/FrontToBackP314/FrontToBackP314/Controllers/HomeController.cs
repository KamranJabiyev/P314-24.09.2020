﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP314.DAL;
using FrontToBackP314.Models;
using FrontToBackP314.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace FrontToBackP314.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            //HttpContext.Session.SetString("group","P314");
            //Response.Cookies.Append("name", "Seynur", new CookieOptions { MaxAge = TimeSpan.FromMinutes(20) });
            HomeVM homeVM = new HomeVM
            {
                Sliders= _db.Sliders,
                SlideContext=_db.SlideContexts.FirstOrDefault(),
                Categories=_db.Categories
            };
            return View(homeVM);
        }

        public IActionResult Test()
        {
            string session=HttpContext.Session.GetString("group");
            string cookie = Request.Cookies["name"];
            return Content(session+" "+ cookie);
        }

        public async Task<IActionResult> AddBasket(int? id)
        {
            if (id == null) return NotFound();
            Product product =await _db.Products.FindAsync(id);
            if (product == null) return NotFound();

            List<BasketVM> basketVMs = new List<BasketVM>();
            if (Request.Cookies["basket"] != null)
            {
                basketVMs = JsonConvert.DeserializeObject<List<BasketVM>>(Request.Cookies["basket"]);
            }

            BasketVM isExistProduct = basketVMs.FirstOrDefault(b => b.Id == id);
            if (isExistProduct == null)
            {
                BasketVM basketVM = new BasketVM { Id = product.Id, Count = 1 };
                basketVMs.Add(basketVM);
            }
            else
            {
                isExistProduct.Count += 1;
            }
            

            string basket = JsonConvert.SerializeObject(basketVMs);
            Response.Cookies.Append("basket", basket, new CookieOptions { MaxAge = TimeSpan.FromDays(10) });
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Basket()
        {
            List<BasketRazorVM> baskets = new List<BasketRazorVM>();
            if (Request.Cookies["basket"] != null)
            {
                List<BasketVM> basketVMs = JsonConvert.DeserializeObject<List<BasketVM>>(Request.Cookies["basket"]);
                foreach (BasketVM basketVM in basketVMs)
                {
                    Product product = await _db.Products.FindAsync(basketVM.Id);
                    BasketRazorVM basketRazorVM = new BasketRazorVM
                    {
                        Id = product.Id,
                        Name = product.Name,
                        Price = product.Price,
                        Image = product.Image,
                        Count = basketVM.Count
                    };
                    baskets.Add(basketRazorVM);
                }
            }
            
            return View(baskets);
        }
    }
}