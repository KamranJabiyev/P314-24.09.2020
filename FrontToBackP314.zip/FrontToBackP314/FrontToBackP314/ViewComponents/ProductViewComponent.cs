﻿using FrontToBackP314.DAL;
using FrontToBackP314.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP314.ViewComponents
{
    public class ProductViewComponent: ViewComponent
    {
        private readonly AppDbContext _db;
        public ProductViewComponent(AppDbContext db)
        {
            _db = db;
        }

        public async Task<IViewComponentResult> InvokeAsync(int count=12)
        {
            IEnumerable<Product> products = _db.Products.Include(p => p.Category).Take(count);
            return View(await Task.FromResult(products));
        }
    }
}
