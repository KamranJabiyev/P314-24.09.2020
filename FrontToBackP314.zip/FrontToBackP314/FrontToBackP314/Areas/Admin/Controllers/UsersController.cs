﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP314.DAL;
using FrontToBackP314.Helpers;
using FrontToBackP314.Models;
using FrontToBackP314.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FrontToBackP314.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class UsersController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly AppDbContext _db;
        public UsersController(UserManager<AppUser> userManager, AppDbContext db,
            RoleManager<IdentityRole> roleManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
            _db = db;
        }
        public async Task<IActionResult> Index()
        {
            List<AppUser> appUsers = _userManager.Users.ToList();
            List<UserVM> userVMs = new List<UserVM>();
            foreach (AppUser user in appUsers)
            {
                UserVM userVM = new UserVM
                {
                    Id = user.Id,
                    Fullname = user.Fullname,
                    Email = user.Email,
                    UserName = user.UserName,
                    Activated = user.Activated,
                    Role = ((await _userManager.GetRolesAsync(user))[0])
                };
                userVMs.Add(userVM);
            }
            return View(userVMs);
        }

        public async Task<IActionResult> Activated(string id)
        {
            if (id == null) return NotFound();
            AppUser user =await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Activated(string id,bool Activated)
        {
            if (id == null) return NotFound();
            AppUser user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();
            user.Activated = Activated;
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> ChangeRole(string id)
        {
            if (id == null) return NotFound();
            AppUser user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            UserVM userVM = new UserVM
            {
                Id = user.Id,
                Fullname = user.Fullname,
                Email = user.Email,
                UserName = user.UserName,
                Activated = user.Activated,
                Role = ((await _userManager.GetRolesAsync(user))[0]),
                Roles = new List<string> { Helper.Roles.Admin.ToString(), Helper.Roles.Member.ToString() }
            };
            return View(userVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangeRole(string id,string Role)
        {
            if (Role == null) return NotFound();
            if (id == null) return NotFound();

            bool existRole=await _roleManager.RoleExistsAsync(Role);
            if(!existRole) return NotFound();

            
            AppUser user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            string oldRole = ((await _userManager.GetRolesAsync(user))[0]);
            IdentityResult identityResult=await _userManager.RemoveFromRoleAsync(user, oldRole);
            if (!identityResult.Succeeded)
            {
                TempData["ChangeRole"] = "Can't change role";
                return RedirectToAction("Index");
            }
            IdentityResult identityR = await _userManager.AddToRoleAsync(user, Role);
            if (!identityR.Succeeded)
            {
                TempData["ChangeRole"] = "Can't change role";
                return RedirectToAction("Index");
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> ResetPassword(string id)
        {
            if (id == null) return NotFound();
            AppUser user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword(string id,string NewPassword)
        {
            if (id == null) return NotFound();
            AppUser user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();
            string token=await _userManager.GeneratePasswordResetTokenAsync(user);
            IdentityResult  identityResult= await _userManager.ResetPasswordAsync(user, token, NewPassword);
            if (!identityResult.Succeeded)
            {
                foreach (var error in identityResult.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
                return View(user);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}