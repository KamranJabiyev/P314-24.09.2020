﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP314.DAL;
using FrontToBackP314.Extentions;
using FrontToBackP314.Helpers;
using FrontToBackP314.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using static FrontToBackP314.Helpers.Helper;

namespace FrontToBackP314.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class SliderController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IHostingEnvironment _env;
        public SliderController(AppDbContext db, IHostingEnvironment env)
        {
            _db = db;
            _env = env;
        }
        public IActionResult Index()
        {
            ViewBag.SlideCount = _db.Sliders.Count();
            return View(_db.Sliders);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Slider slider)
        {
            #region Create one photo
            //if(ModelState["Photo"].ValidationState== ModelValidationState.Invalid)
            //{
            //    return View();
            //}

            //if (!slider.Photo.IsImage("image/"))
            //{
            //    ModelState.AddModelError("Photo", "Please select only image format!!!");
            //    return View();
            //}

            //if(slider.Photo.MaxLength(300))
            //{
            //    ModelState.AddModelError("Photo", "Image's max size must be 300kb!!!");
            //    return View();
            //}

            ////string folder=Path.Combine("img","slide");
            //string fileName =await slider.Photo.SaveImage(_env.WebRootPath, "img");

            //slider.Image = fileName;
            //await _db.Sliders.AddAsync(slider);
            #endregion
            if (ModelState["Photos"].ValidationState == ModelValidationState.Invalid)
            {
                return View();
            }

            ViewBag.SlideCount = _db.Sliders.Count();
            if (ViewBag.SlideCount + slider.Photos.Length > 5)
            {
                ModelState.AddModelError("Photos", $"Maximum {5 - ViewBag.SlideCount} image can select");
                return View();
            }

            foreach (var photo in slider.Photos)
            {
                if (!photo.IsImage("image/"))
                {
                    ModelState.AddModelError("Photos", $"{photo.FileName} - Please select only image format!!!");
                    return View();
                }
                if (photo.MaxLength(300))
                {
                    ModelState.AddModelError("Photos", $"{photo.FileName} - Image's max size must be 300kb!!!");
                    return View();
                }

                string fileName = await photo.SaveImage(_env.WebRootPath, "img");
                Slider sliderNew = new Slider();
                sliderNew.Image = fileName;
                await _db.Sliders.AddAsync(sliderNew);
                await _db.SaveChangesAsync();
            }
            
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null) return NotFound();
            Slider slider = await _db.Sliders.FindAsync(id);
            if (slider == null) return NotFound();
            return View(slider);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id,Slider slider)
        {
            if (slider.Photo != null)
            {
                if (!slider.Photo.IsImage("image/"))
                {
                    ModelState.AddModelError("Photo", "Please select only image format!!!");
                    return View();
                }

                if (slider.Photo.MaxLength(300))
                {
                    ModelState.AddModelError("Photo", "Image's max size must be 300kb!!!");
                    return View();
                }

                string fileName = await slider.Photo.SaveImage(_env.WebRootPath, "img");
                Slider sliderDb = await _db.Sliders.FindAsync(id);
                Helper.DeleteImg(_env.WebRootPath, "img", sliderDb.Image);

                sliderDb.Image = fileName;
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            Slider slider = await _db.Sliders.FindAsync(id);
            if (slider == null) return NotFound();
            return View(slider);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id == null) return NotFound();
            Slider slider =await _db.Sliders.FindAsync(id);
            if (slider == null) return NotFound();

            Helper.DeleteImg(_env.WebRootPath, "img", slider.Image);

            _db.Sliders.Remove(slider);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}